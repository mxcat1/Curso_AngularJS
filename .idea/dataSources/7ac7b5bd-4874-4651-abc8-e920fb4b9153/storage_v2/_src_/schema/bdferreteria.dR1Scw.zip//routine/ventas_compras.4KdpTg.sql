create procedure ventas_compras(IN mes int, IN ano int)
  begin
    select sum(DM.Precio_Unitario) as Total from movimientos as M
      inner join detalle_movimientos as DM
        on M.Codigo_Movimiento=DM.Codigo_Movimiento
      inner join productos as P
        on P.Codigo_Producto=DM.Codigo_Producto where MONTH(M.Fecha)=mes and year(M.Fecha)=ano
    group by M.Tipo_Movimiento;
  end;

