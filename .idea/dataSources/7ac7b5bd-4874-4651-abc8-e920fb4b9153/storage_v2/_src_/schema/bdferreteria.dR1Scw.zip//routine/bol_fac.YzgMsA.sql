create procedure bol_fac(IN tipo varchar(100), IN fecha varchar(100))
  begin
    select M.Codigo_Movimiento,M.Fecha, M.Numero_Comprobante , M.Tipo_Comprobante, sum(DM.Cantidad_Producto*DM.Precio_Unitario) Monto from movimientos M
          inner join detalle_movimientos DM
              on M.Codigo_Movimiento=DM.Codigo_Movimiento
    where M.Tipo_Comprobante=tipo and M.Fecha like concat(fecha,'%')
    group by M.Codigo_Movimiento;
  end;

